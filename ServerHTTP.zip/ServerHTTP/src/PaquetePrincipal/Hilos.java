/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PaquetePrincipal;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author diego
 */

public class Hilos extends Thread{
    
    private Socket sCliente;
    private ServidorHTTP servidorHTTP;
    
    public Hilos(Socket sCliente) {
        this.sCliente = sCliente;
    }

    @Override
    public void run() {
        try {
            InetAddress inetAddress = sCliente.getInetAddress();
            String host = inetAddress.getHostAddress();
            System.out.println("Se ha conectado el cliente con ip " + host);
            servidorHTTP.procesaPeticion(sCliente);
            sCliente.close();
            System.out.println("El cliente " + host + " se ha desconectado");
        } catch (IOException ex) {
            Logger.getLogger(Hilos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
}
